#include <iostream>
#include <vector>
#include <list>
#include <utility>
#include <memory>
#include <cfloat>
#include <fstream>
#include <ctime>
#include <climits>

#ifdef WIN32

#include <windows.h>

#endif

template<typename ItemType>
class Matrix {
public:
    explicit Matrix(size_t size = 0, ItemType values = 0);

    // доступ к элементам по индексам
    const ItemType &item(size_t row, size_t column) const;
    ItemType &item(size_t row, size_t column);
    const ItemType &operator()(size_t row, size_t column) const;
    ItemType &operator()(size_t row, size_t column);

    // получение "реальных" идексов
    // e.g. если была удалена строка 1 rowIndex(1) == 2
    // ?необходимо для алгоритма Литтла
    size_t rowIndex(size_t row) const;
    size_t columnIndex(size_t column) const;

    // размерность матрицы
    size_t size() const;
    // вывод на экран
    void print() const;
    void printEndl() const;

    // удаление строки и столбца по индексам
    void removeRowColumn(size_t row, size_t column);

    Matrix(const Matrix &) = default;
    Matrix &operator=(const Matrix &) = default;

private:
    // инициализация "реальных" номеров строк и столбцов
    void initRowsColumns();

    std::vector<std::vector<ItemType>> _items;
    // "реальные" номера строк
    std::vector<size_t> _rows;
    // "реальные" номера столбцов
    std::vector<size_t> _columns;
};

template<typename ItemType>
inline Matrix<ItemType>::Matrix(size_t size, ItemType values)
        :_items(size, std::vector<ItemType>(size, values)), _rows(size), _columns(size) {
    initRowsColumns();
}

template<typename ItemType>
inline const ItemType &Matrix<ItemType>::item(size_t row, size_t column) const {
    return _items[row][column];
}

template<typename ItemType>
inline ItemType &Matrix<ItemType>::item(size_t row, size_t column) {
    // по имя искоренения дублирования кода
    return const_cast<ItemType &>(static_cast<const Matrix<ItemType> &>(*this).item(row, column));
}

template<typename ItemType>
inline const ItemType &Matrix<ItemType>::operator()(size_t row, size_t column) const {
    return item(row, column);
}

template<typename ItemType>
inline ItemType &Matrix<ItemType>::operator()(size_t row, size_t column) {
    return item(row, column);
}

template<typename ItemType>
inline size_t Matrix<ItemType>::rowIndex(size_t row) const {
    return _rows[row];
}

template<typename ItemType>
inline size_t Matrix<ItemType>::columnIndex(size_t column) const {
    return _columns[column];
}

template<typename ItemType>
inline void Matrix<ItemType>::removeRowColumn(size_t row, size_t column) {
    // удаление индексов
    _rows.erase(_rows.begin() + row);
    _columns.erase(_columns.begin() + column);
    // удаление строки
    _items.erase(_items.begin() + row);
    // удаление столбца
    for (size_t i = 0; i < _items.size(); i++)
        _items[i].erase(_items[i].begin() + column);
}

template<typename ItemType>
inline size_t Matrix<ItemType>::size() const {
    return _items.size();
}

template<typename ItemType>
inline void Matrix<ItemType>::print() const {
    printf("         ");
    for (auto iter = _columns.cbegin(); iter != _columns.cend(); ++iter)
        printf("%8u ", *iter);
    puts("");
    for (size_t i = 0; i < _items.size(); i++) {
        printf("%8u ", _rows[i]);
        for (size_t j = 0; j < _items.size(); j++) {
            printf("%8.2f ", _items[i][j]);
        }
        puts("");
    }
}

template<typename ItemType>
inline void Matrix<ItemType>::printEndl() const {
    print();
    puts("");
}

template<typename ItemType>
inline void Matrix<ItemType>::initRowsColumns() {
    for (size_t i = 0; i < _rows.size(); i++)
        _rows[i] = _columns[i] = i;
}

class LittleSolver {
public:
    // список вершин как список пар номеров смежных вершин
    using arclist = std::list<std::pair<size_t, size_t>>;
    using MatrixD = Matrix<long long>;
    using MatrixPtr = std::unique_ptr<MatrixD>;

    // на вход матрица расстояний и требуемая верхняя граница
    LittleSolver(const Matrix<long long> &m, long long record = LONG_MAX);
    ~LittleSolver();

    // основной метод
    void solve();

    // получить решение
    std::list<size_t> getSolution() const;
    // получить послейдний шаг
    // [нужно только для визуализации]
    arclist getLastStep() const;
    // получить лучшее промежуточное решение
    // [нужно только для визуализации]
    arclist getBestStep() const;
    // получить рекорд
    long long getRecord() const;
    // было ли найдето решение, не превышающее заданную границу
    bool isSolved() const;

    // не должен быть скопирован
    LittleSolver(const LittleSolver &) = delete;
    LittleSolver &operator=(const LittleSolver &) = delete;

private:
    // основная рекурсивная функция поиска пути
    // m - текущая матрица стоимостей
    // arcs - текущий найденный путь
    // bottomLimit - текущая нижняя граница
    void handleMatrix(const Matrix<long long> &m, const arclist &arcs, long long bottomLimit);
    // суммарная длина набора ребер
    long long cost(const arclist &arcs) const;
    // сравнить предложенное решение с оптимальным
    void candidateSolution(const arclist &arcs);
    // добавление недостающей бесконечности в матрицу
    // стоимостей для избежания преждевременных циклов
    void addInfinity(MatrixD &m);
    // произвести ряд вычитаний, чтобы в каждой строке
    // и каждом столбце были бесконечности.
    // возвращает значение, на которое увеличится нижняя граница
    long long subtractFromMatrix(MatrixD &m) const;
    // поиск нулевых коэффициентов с максимальными коэффициентами
    std::list<std::pair<size_t, size_t>> findBestZeros(const MatrixD &matrix) const;
    // получение коэффициента для элемента (r, c)
    // r - row; c - column
    static long long getCoefficient(const MatrixD &m, size_t r, size_t c);
    // записать последний проверенный путь
    void logPath(const arclist &path);

    // исходная матрица расстояний
    MatrixPtr _sourceMatrix;
    // рекорд, он же длина лучшего пути, он же верхняя граница
    //std::atomic<double> _record;
    long long _record;
    // лучшее решение
    arclist _arcs;
    // итоговое решение
    std::list<size_t> _solution;
    // последний просмотренный список ребер
    arclist _lastStep;
    // для доступа к промежуточным результатам из другого потока
    // mutable std::mutex _mutex;
    // значение, принимаемое за бесконечность
    //double _infinity;
    long long _infinity;
};

LittleSolver::LittleSolver(const Matrix<long long> &m, long long record) : _record(record), _infinity(0) {

    _sourceMatrix = std::make_unique<MatrixD>(m);

    // сумма всех элементов матрицы выступает в качестве бесконечности
    for (size_t i = 0; i < m.size(); i++)
        for (size_t j = i + 1; j < m.size(); j++)
            _infinity += (m.item(i, j) + m.item(j, i));

    //_infinity= 10000;


    // заполнение диагонали бесконечностями
    for (size_t i = 0; i < _sourceMatrix->size(); i++)
        _sourceMatrix->item(i, i) = _infinity;




    /*std::cout << "infinity= " << _infinity << std::endl;
     std::cout << "After adding infinity " << std::endl;
     for (int i = 0; i < 10; i++) {

         for (int j = 0; j < 10; j++) {
             std::cout << _sourceMatrix->item(i, j) << " ";
         }
         std::cout << std::endl;
     }*/

}

LittleSolver::~LittleSolver() {}

void LittleSolver::solve() {
    // решение
    handleMatrix(*_sourceMatrix, arclist(), 0);
    // запись решения
    // добавление нулевой вершины как начальной
    _solution.push_back(0);
    // посик следующей вершины
    while (!_arcs.empty()) {
        auto iter = _arcs.begin();
        while (iter != _arcs.end()) {
            // если есть ребро, исходящее из последней вершины
            // добавление в решение смежной вершины
            // и удаление этого ребра из списка
            if (iter->first == _solution.back()) {
                _solution.push_back(iter->second);
                iter = _arcs.erase(iter);

            } else
                ++iter;
        }
    }


    std::cout << "Way ";
    std::list<size_t>::iterator it = _solution.begin();
    for (int i = 0; i < _solution.size(); i++) {
        std::cout << *it << " ";
        ++it;
    }
    std::cout << std::endl;
    std::cout << "Length of Way " << _record;

    std::string result = "";
    result = result + "resultLittleAlgoritm.txt";

    std::ofstream out; // поток для записи
    //out.open("D:/My_Documents/Documents/Универ/Output");// открываем файл для записи
    out.open(result);// открываем файл для записи
    if (out.is_open()) {
        out << "Путь (Литтл) ";
        std::list<size_t>::iterator it = _solution.begin();
        for (int i = 0; i < _solution.size(); i++) {
            out << *it << " ";
            ++it;
        }
        out << std::endl;
        out << "Длина пути (Литтл) " << _record;

    }

    /* list<size_t>::iterator it = getSolution().begin();
     for (int i = 0; i < getSolution().size(); i++)
     {
         std::cout << *it;
         ++it;
     }*/
    // auto iter2 = _arcs.begin();
    //while(iter2 != _arcs.end()){

    //iter2++;
    //  }
}

std::list<size_t> LittleSolver::getSolution() const {
    //  std::cout << "getSolution";
    return _solution;

}

LittleSolver::arclist LittleSolver::getLastStep() const {
    // std::lock_guard<std::mutex> g(_mutex);
    return _lastStep;
}

LittleSolver::arclist LittleSolver::getBestStep() const {
    //  std::lock_guard<std::mutex> g(_mutex);
    return _arcs;
}

long long LittleSolver::getRecord() const {
    return _record;
}

bool LittleSolver::isSolved() const {
    return _solution.size() != 1;
}

void LittleSolver::handleMatrix(const Matrix<long long> &m, const arclist &path, long long bottomLimit) {
    if (m.size() < 2)
        throw std::logic_error("Matrix smaller than 2x2");
    // если матрица меньше 2, решение заканчивается
    if (m.size() == 2) {
        // записать текущий путь как последний рассмотренный
        logPath(path);
        // выбор элемента, не равного бесконечности, в первой строке
        int i = m.item(0, 0) >= _infinity ? 1 : 0;
        // создание списка с результирующим путем
        arclist result(path);
        // добавление индексов элементов, не равных бесконечности
        result.emplace_back(m.rowIndex(0), m.columnIndex(i));
        result.emplace_back(m.rowIndex(1), m.columnIndex(1 - i));
        // сравнение пути с минимальным
        candidateSolution(result);
        return;
    }
    // создается копия переданной матрицы, т.к. он константна
    Matrix<long long> matrix(m);
    // вычитание минимальных элементов строк и столбцов
    // увеличение нижней границы
    bottomLimit += subtractFromMatrix(matrix);

    // сравнение верхней и нижней границ

    if (bottomLimit > _record) {

        // записать текущий путь как последний рассмотренный
        logPath(path);
        return;
    }


    // получение списка нулевых элементов с максимальными коэффициентами
    // на самом деле достаточно одного
    auto zeros = findBestZeros(matrix);

    // переход к множествам, содержащим и не содержащим ребро edge
    auto edge = zeros.front();

    // копия матрицы
    auto newMatrix(matrix);


    //     из матрицы удаляются строка и столбец, соответствующие вершинам ребра
    newMatrix.removeRowColumn(edge.first, edge.second);

    //     ребро iter добавляется к пути
    auto newPath(path);
    newPath.emplace_back(matrix.rowIndex(edge.first), matrix.columnIndex(edge.second));

    // добавление бесконечности для избежания преждевремнного цикла
    addInfinity(newMatrix);

    // обработка множества, содержащего ребро edge
    handleMatrix(newMatrix, newPath, bottomLimit);

    // переход к множеству, не сожержащему ребро edge
    // снова копирование матрицы текущего шага
    newMatrix = matrix;
    // добавление бесконечности на место iter
    newMatrix(edge.first, edge.second) = _infinity + 1;
    // обработка множества, не сожержащего ребро edge
    handleMatrix(newMatrix, path, bottomLimit);


}

long long LittleSolver::cost(const arclist &arcs) const {
    // инициализация нулем
    long long result(0);
    for (auto &iter: arcs)
        // суммирование элементов исходной матрицы, соответствующих ребрам
        result += _sourceMatrix->item(iter.first, iter.second);

    return result;
}

void LittleSolver::candidateSolution(const arclist &arcs) {
    long long curCost;
    // сравнение рекорда со стоимостью текущего пути
    if (_record < (curCost = cost(arcs))) {
        return;
    }
    //   std::lock_guard<std::mutex> g(_mutex);
    // копирование стоимости и пути
    _record = curCost;
    _arcs = arcs;
}

void LittleSolver::addInfinity(MatrixD &m) {
    // массивы с информацией о том, в каких столбцах и строках содержится бесконечность
    std::vector<bool> infRow(m.size(), false), infColumn(m.size(), false);
    // обход всей матрицы
    for (size_t i = 0; i < m.size(); i++)
        for (size_t j = 0; j < m.size(); j++)
            if (m.item(i, j) == _infinity) {
                infRow[i] = true;
                infColumn[j] = true;
                // std::cout << "addInfinity";
            }
    // поиск строки, не содержащей бесконечности
    //А что если НЕ БУДЕТ строки не содержащей бесконечности??? Что если все они будут содержать бесконечность???
    size_t notInf; //=-1;
    for (size_t i = 0; i < infRow.size(); i++)
        if (!infRow[i]) {
            notInf = i;
            // std::cout << "addInfinity2";
            break;
        }

    // поиск столбца, не содаржащего бесконечности и добавление бесконечности
    // if (notInf == -1) { std::cout << "   notInf==-1   "; }
    // if (notInf != -1) {
    //   std::cout << "addInfinity3";
    for (size_t j = 0; j < infColumn.size(); j++)
        if (!infColumn[j]) {
            m.item(notInf, j) = _infinity;
            break;
        }
    //}
}

/*void LittleSolver::addInfinity(Matrix<unsigned long long>& m) {
    // массивы с информацией о том, в каких столбцах и строках содержится бесконечность
    vector<bool> infRow(m.size(), false), infColumn(m.size(), false);
    // обход всей матрицы
    for (size_t i = 0; i < m.size(); i++)
        for (size_t j = 0; j < m.size(); j++)
            if (m.item(i, j) == _infinity) {
                infRow[i] = true;
                infColumn[j] = true;
               // std::cout << "addInfinity";
            }
    // поиск строки, не содержащей бесконечности
    //А что если НЕ БУДЕТ строки не содержащей бесконечности??? Что если все они будут содержать бесконечность???
    size_t notInf; //=-1;
    for (size_t i = 0; i < infRow.size(); i++)
        if (!infRow[i]) {
            notInf = i;
           // std::cout << "addInfinity2";
            break;
        }

    // поиск столбца, не содаржащего бесконечности и добавление бесконечности
   // if (notInf == -1) { std::cout << "   notInf==-1   "; }
   // if (notInf != -1) {
     //   std::cout << "addInfinity3";
        for (size_t j = 0; j < infColumn.size(); j++)
            if (!infColumn[j]) {
                m.item(notInf, j) = _infinity;
                break;
            }
    //}
}*/

long long LittleSolver::subtractFromMatrix(MatrixD &m) const {
    // сумма всех вычтенных значений
    long long substractSum = 0;
    // массивы с минимальными элементами строк и столбцов
    std::vector<long long> minRow(m.size(), LONG_MAX), minColumn(m.size(), LONG_MAX);
    // обход всей матрицы
    for (size_t i = 0; i < m.size(); ++i) {
        for (size_t j = 0; j < m.size(); ++j) {
            // поиск минимального элемента в строке
            if (m(i, j) < minRow[i]) {
                minRow[i] = m(i, j);

            }
        }

        for (size_t j = 0; j < m.size(); ++j) {
            // вычитание минимальных элементов из всех
            // элементов строки кроме бесконечностей
            if (m(i, j) < _infinity) {
                m(i, j) -= minRow[i];
            }
            // поиск минимального элемента в столбце после вычитания строк
            if ((m(i, j) < minColumn[j]))
                minColumn[j] = m(i, j);
        }
    }

    // вычитание минимальных элементов из всех
    // элементов столбца кроме бесконечностей
    for (size_t j = 0; j < m.size(); ++j)
        for (size_t i = 0; i < m.size(); ++i)
            if (m(i, j) < _infinity) {
                m(i, j) -= minColumn[j];
            }

    // суммирование вычтенных значений
    for (auto i: minRow)
        substractSum += i;

    for (auto i: minColumn)
        substractSum += i;

    return substractSum;
}

std::list<std::pair<size_t, size_t>> LittleSolver::findBestZeros(const MatrixD &matrix) const {
    // список координат нулевых элементов
    std::list<std::pair<size_t, size_t>> zeros;
    // список их коэффициентов
    std::list<long long> coeffList;


    // максимальный коэффициент
    long long maxCoeff = 0;
    // поиск нулевых элементов
    for (size_t i = 0; i < matrix.size(); ++i) {
        for (size_t j = 0; j < matrix.size(); ++j) {

            // если равен нулю
            if (!matrix(i, j)) {
                // добавление в список координат

                zeros.emplace_back(i, j);

                // расчет коэффициена и добавление в список
                coeffList.push_back(getCoefficient(matrix, i, j));
                // сравнение с максимальным
                maxCoeff = std::max(maxCoeff, coeffList.back());
            }
        }
    }
    { // область видимости итераторов
        auto zIter = zeros.begin();
        auto cIter = coeffList.begin();
        while (zIter != zeros.end()) {
            if (*cIter != maxCoeff) {
                // если коэффициент не максимальный, удаление его из списка
                zIter = zeros.erase(zIter);
                cIter = coeffList.erase(cIter);
            } else {
                ++zIter;
                ++cIter;
            }
        }
    }

    return zeros;
}

long long LittleSolver::getCoefficient(const MatrixD &m, size_t r, size_t c) {
    long long rmin, cmin;
    // rmin = cmin = DBL_MAX;
    rmin = cmin = LONG_MAX;
    // обход строки и столбца
    for (size_t i = 0; i < m.size(); ++i) {
        if (i != r)
            rmin = std::min(rmin, m(i, c));
        if (i != c)
            cmin = std::min(cmin, m(r, i));
    }

    return rmin + cmin;
}

void LittleSolver::logPath(const LittleSolver::arclist &path) {
    //   std::lock_guard<std::mutex> g(_mutex);
    _lastStep = path;
}

class BruteforceSolver {
public:
    using MatrixD = Matrix<long long>;
    BruteforceSolver(const Matrix<long long> &m);

    // решить TSP
    void solve();
    // один переборный шаг
    // вернет false после полного перебора
    bool step();

    // получить решение
    std::list<size_t> getSolution() const;
    // получить результат последнего шага
    std::list<size_t> getLastStep() const;
    // получить длину лучшего результата
    long long getRecord() const;

    // не должен быть копирован
    BruteforceSolver(const BruteforceSolver &) = delete;
    BruteforceSolver &operator=(const BruteforceSolver &) = delete;

private:
    // длина пути
    long long cost(std::vector<size_t> solution) const;
    // сравнить предложенное решение с оптимальным
    void candidateSolution(std::vector<size_t> solution);

    // исходная матрица расстояний
    MatrixD _matrix;
    // рекорд - длина лучшего пути
    // atomic для корректного чтения из другого потока
    //std::atomic<double> _record;
    long long _record;
    // лучший путь
    std::list<size_t> _solution;
    // последний рассмотренный путь
    std::vector<size_t> _lastSolution;
    // для доступа к промежуточным результатам из другого потока
    //mutable std::mutex _mutex;
};

BruteforceSolver::BruteforceSolver(const Matrix<long long> &m) : _matrix(m), _record(LONG_MAX) {
    // начальная инициализация пути
    _lastSolution.resize(m.size());
    for (size_t i = 0; i < m.size(); ++i)
        _lastSolution[i] = i;

    candidateSolution(_lastSolution);
}

void BruteforceSolver::solve() {
    if (_matrix.size() <= 2)
        throw "matrix smaller than 2x2";

    while (step());


}

bool BruteforceSolver::step() {
    // перебор всех возможных подстановок
    // код взят с prog-cpp.ru/permutation/
    size_t n = _lastSolution.size() - 1;
    int j = n - 2;
    while (j != -1 && _lastSolution[j] >= _lastSolution[j + 1]) j--;
    if (j == -1) {
        std::cout << std::endl;
        std::cout << "Way ";
        std::list<size_t>::iterator it = _solution.begin();
        for (int i = 0; i < _solution.size(); i++) {

            std::cout << *it << " ";
            ++it;
        }
        std::cout << std::endl;
        std::cout << "Length of Way " << _record;

        std::string result = "";
        result = result + "resultRudeAlgoritm.txt";


        std::ofstream out; // поток для записи
        out.open(result);// открываем файл для записи
        if (out.is_open()) {
            out << "Путь (перебор) ";
            std::list<size_t>::iterator it = _solution.begin();
            for (int i = 0; i < _solution.size(); i++) {
                out << *it << " ";
                ++it;
            }
            out << std::endl;
            out << "Длина пути (перебор) " << _record;

        }


        return false;
    }
    int k = n - 1;
    while (_lastSolution[j] >= _lastSolution[k])
        k--;
    std::swap(_lastSolution[j], _lastSolution[k]);
    int l = j + 1, r = n - 1;
    while (l < r)
        std::swap(_lastSolution[l++], _lastSolution[r--]);
    candidateSolution(_lastSolution);
    return true;
}

std::list<size_t> BruteforceSolver::getSolution() const {
    return _solution;
}

std::list<size_t> BruteforceSolver::getLastStep() const {
    // lock_guard<mutex> g(_mutex);
    std::list<size_t> solution;
    for (const auto &iter: _lastSolution)
        solution.push_back(iter);
    solution.push_back(solution.front());
    return solution;
}

long long BruteforceSolver::getRecord() const {
    return _record;
}

long long BruteforceSolver::cost(std::vector<size_t> solution) const {
    long long result = 0;
    // сумма стоимостей ребер
    for (size_t i = 1; i < solution.size(); ++i)
        result += _matrix(solution[i - 1], solution[i]);
    result += _matrix(solution.back(), solution.front());
    return result;
}

void BruteforceSolver::candidateSolution(std::vector<size_t> solution) {
    long long curCost = cost(solution);
    // если стоимость первышает рекордную - возврат
    if (curCost >= _record)
        return;
    //  lock_guard<mutex> g(_mutex);
    // новый рекорд
    _record = curCost;
    _solution.clear();
    // копирование нового решения
    for (const auto &iter: solution)
        _solution.push_back(iter);
    _solution.push_back(solution.front());
}

std::vector<std::string> split(const std::string &str, const std::string &delim) {
    std::vector<std::string> tokens;
    size_t prev = 0, pos = 0;
    do {
        pos = str.find(delim, prev);
        if (pos == std::string::npos) pos = str.length();
        std::string token = str.substr(prev, pos - prev);
        if (!token.empty()) tokens.push_back(token);
        prev = pos + delim.length();
    } while (pos < str.length() && prev < str.length());
    return tokens;
}

int main() {
    long long SIZE;
    ///////////

#ifdef WIN32

    SetConsoleCP(65001);
    SetConsoleOutputCP(65001);

#endif

    int temp, minindex, min;
    int begin_index = 0;
    int DIM1;
    using MatrixD = Matrix<long long>;



    std::string input;
    std::cout << "Введите путь к файлу с данными" << std::endl;
    std::cin >> input;
    std::ifstream f(input);
    std::ifstream h(input);
    std::string line;
    if (!f.is_open()) {
        std::cout << "Введен некорректный файл!" << std::endl;
        return 0;

    } else {
        while (getline(h, line)) {

            SIZE = stoi(split(line, " ")[0]);

        }

        MatrixD distances(SIZE);
        MatrixD distancesNew(SIZE);
        for (int i = 0; i < SIZE; i++) {

            for (int j = 0; j < SIZE; j++) {
                // приравнивание изначально к бесконечностям;
                distances(i, j) = 0;
                distancesNew(i, j) = 0;
            }
        }
        std::cout << std::endl;

        while (getline(f, line)) {
            int i = stoi(split(line, " ")[0]);

            int j = stoi(split(line, " ")[1]);

            int k = stoi(split(line, " ")[2]);
            distances(i - 1, j - 1) = k;
            distancesNew(i - 1, j - 1) = k;

        }

        f.close();// закрываем файл
        h.close();

        std::vector<int> d(SIZE);// минимальное расстояние
        std::vector<int> v(SIZE);// посещенные вершины
        std::cout << "Считанная матрица расстояний" << std::endl;
        for (int i = 0; i < SIZE; i++) {

            for (int j = 0; j < SIZE; j++) {
                std::cout << distancesNew(i, j) << " ";
            }
            std::cout << std::endl;
        }
        std::cout << std::endl;

        for (int P = 0; P < SIZE; P++) {
            //Инициализация вершин и расстояний
            for (int i = 0; i < SIZE; i++) {
                d[i] = 10000;
                v[i] = 1;

            }
            begin_index = P;
            d[begin_index] = 0;

            // Шаг алгоритма
            do {
                minindex = 10000;
                min = 10000;
                for (int i = 0; i < SIZE; i++) { // Если вершину ещё не обошли и вес меньше min
                    if ((v[i] == 1) && (d[i] < min)) { // Переприсваиваем значения
                        min = d[i];
                        minindex = i;
                    }
                }
                // Добавляем найденный минимальный вес
                // к текущему весу вершины
                // и сравниваем с текущим минимальным весом вершины
                if (minindex != 10000) {
                    for (int i = 0; i < SIZE; i++) {
                        if (distances(minindex, i) > 0) {
                            temp = min + distances(minindex, i);
                            if (temp < d[i]) {
                                d[i] = temp;
                            }
                        }
                    }
                    v[minindex] = 0;
                }
            } while (minindex < 10000);
            // Вывод кратчайших расстояний до вершин
            for (int i = 0; i < SIZE; i++) {
                if (distancesNew(P, i) == 0) {
                    distancesNew(P, i) = d[i];
                }
            }
            temp = 0;
            for (int i = 0; i < SIZE; i++) {

                for (int j = 0; j < SIZE; j++) {
                    std::cout << distancesNew(i, j) << " ";
                }
                std::cout << std::endl;
            }
        }

        std::cout << "Матрица расстояний после преобразования" << std::endl;
        for (int i = 0; i < SIZE; i++) {

            for (int j = 0; j < SIZE; j++) {
                std::cout << distancesNew(i, j) << " ";
            }
            std::cout << std::endl;
        }
        std::cout << std::endl;

        std::cout << "Выберете алгоритм:" << std::endl;
        std::cout << "1 - Метод ветвей и границ(Алгоритм Литтла)" << std::endl;
        std::cout << "2 - Алгоритм грубой силы" << std::endl;
        std::cout << "3 - Метод ветвей и границ(Алгоритм Литтла) и Алгоритм грубой силы " << std::endl;
        int type = 0;
        std::cin >> type;
        switch (type) {
            case 1: {
                LittleSolver *solv = new LittleSolver(distancesNew);
                std::cout << "Результаты метода ветвей и границ" << std::endl;
                unsigned int start_time = clock();
                solv->solve();
                unsigned int end_time = clock();
                std::cout << std::endl;
                unsigned int search_time = end_time - start_time;
                std::cout << "Algoritm's time " << search_time << std::endl;
                std::string result = "";
                result = result + "resultTime.txt";
                std::ofstream out;          // поток для записи
                out.open(result); // окрываем файл для записи
                if (out.is_open()) {
                    out << "Время выполнения Метода Ветвей и границ на " << SIZE << " вершинах " << search_time
                        << std::endl;
                    out << std::endl;
                    out.close();
                } else {
                    std::cout << "Некорректный ввод";
                }

                std::cout << "Результат работы Метода ветвей и границ на диске D в файле resultLittleAlgoritm"
                          << std::endl;
                std::cout << "Временной результат на диске D в файле resultTime" << std::endl;
                break;
            }
            case 2: {
                BruteforceSolver *brSolv = new BruteforceSolver(distancesNew);
                std::cout << "Результаты метода грубой силы" << std::endl;
                unsigned int start_time2 = clock();
                brSolv->solve();
                unsigned int end_time2 = clock();
                unsigned int search_time2 = end_time2 - start_time2;
                std::cout << std::endl;
                std::cout << "Algoritm's time " << search_time2 << std::endl;
                std::string result = "";
                result = result + "resultTime.txt";
                std::ofstream out;          // поток для записи
                out.open(result); // окрываем файл для записи
                if (out.is_open()) {

                    out << "Время выполнения Метода Грубой силы на " << SIZE << " вершинах " << search_time2
                        << std::endl;
                    out << std::endl;
                    out.close();
                } else {
                    std::cout << "Некорректный ввод";
                }


                std::cout << "Результат работы Метода грубой силы на диске D в файле resultRudeAlgoritm" << std::endl;
                std::cout << "Временной результат на диске D в файле resultTime" << std::endl;
                break;
            }
            case 3: {
                LittleSolver *solv = new LittleSolver(distancesNew);
                std::cout << "Результаты метода ветвей и границ" << std::endl;
                unsigned int start_time = clock();
                solv->solve();
                unsigned int end_time = clock();
                std::cout << std::endl;
                unsigned int search_time = end_time - start_time;
                std::cout << "Algoritm's time " << search_time << std::endl;

                std::cout << std::endl;
                BruteforceSolver *brSolv = new BruteforceSolver(distancesNew);
                std::cout << "Результаты метода грубой силы" << std::endl;
                unsigned int start_time2 = clock();
                brSolv->solve();
                unsigned int end_time2 = clock();
                unsigned int search_time2 = end_time2 - start_time2;
                std::cout << std::endl;
                std::cout << "Algoritm's time " << search_time2 << std::endl;
                std::string result = "";
                result = result + "resultTime.txt";
                std::ofstream out;          // поток для записи
                out.open(result); // окрываем файл для записи
                if (out.is_open()) {
                    out << "Время выполнения Метода Ветвей и границ на " << SIZE << " вершинах " << search_time
                        << std::endl;
                    out << "Время выполнения Метода Грубой силы на " << SIZE << " вершинах " << search_time2
                        << std::endl;
                    out << std::endl;
                    out.close();
                } else {
                    std::cout << "Некорректный ввод";
                }

                std::cout << "Результат работы Метода ветвей и границ на диске D в файле resultLittleAlgoritm"
                          << std::endl;
                std::cout << "Результат работы Метода перебором на диске D в файле resultRudeAlgoritm" << std::endl;
                std::cout << "Временной результат на диске D в файле resultTime" << std::endl;
                break;
            }
            case 0:
                std::cout << "Необходимо выбрать 1, 2 или 3";


        }

        ///////////////////////////////////
    }
}

