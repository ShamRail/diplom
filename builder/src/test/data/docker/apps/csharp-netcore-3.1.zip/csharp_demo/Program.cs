﻿using System;

namespace csharp_demo
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = int.Parse(args[0]);
            int b = int.Parse(args[1]);
            Console.WriteLine(a + b);
        }
    }
}
