#include <stdio.h>
#include <string.h>

int convert(char* num) {
    int result = 0;
    int len = strlen(num);
    for(int i = 0; i < len; i++) {
        result = result * 10 + ( num[i] - '0' );
    }
    return result;
}

int main(int argc, char* argv[]) {
  int a = convert(argv[1]);
  int b = convert(argv[2]);
  printf("%d\n", a + b);
  return 0;
}

