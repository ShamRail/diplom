#include <iostream>

using namespace std;

int main(int argc, char *argv[]) {
     
    string first = argv[1];
    string second = argv[2];
    
    int a = std::stoi(first);
    int b = std::stoi(second);
    cout << a + b << "\n";
    
    return 0; 
}
