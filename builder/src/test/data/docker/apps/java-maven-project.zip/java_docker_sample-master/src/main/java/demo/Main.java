package demo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        List<String> phrases = Files.readAllLines(Path.of("./in/phrases.txt"));
        Random random = new Random(123);
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(args[0]);
        List<String> log = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            System.out.print("You: ");
            String userInput = scanner.nextLine();
            String botAnswer = getRandomString(phrases, random);
            System.out.printf("Bot: %s%n", botAnswer);
            log.add(String.format("You: %s", userInput));
            log.add(String.format("Bot: %s", botAnswer));
        }
        Files.write(Path.of("./out/log.txt"), log);
    }

    private static String getRandomString(List<String> strings, Random random) {
        return strings.get(random.nextInt(strings.size()));
    }

}
